# WebPix

O experimento pode ser testado [aqui](http://caiogondim.github.com/webpix)

Detalhes da implementação podem ser visto [neste post](http://loopinfinito.com.br/2012/11/20/html5-camera-com-webpix/) do [@loopinfinito](http://twitter.com/loopinfinito)
